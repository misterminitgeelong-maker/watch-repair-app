# Handoff: Mainspring Visual Redesign — "Refined Warmth"

## Overview

This handoff documents a full visual overhaul of the Mainspring watch/shoe/mobile repair management app. The redesign evolves the existing "café" theme into a more professional, premium aesthetic — retaining the warmth and brand identity while sharpening typography, tightening spacing, and introducing clearer information hierarchy across all major screens.

**Target codebase:** `misterminitgeelong-maker/watch-repair-app` — React + TypeScript + Tailwind v4, Vite, Capacitor. The frontend lives in `frontend/src/`.

## About the Design Files

The files bundled in this package (`*.html`) are **high-fidelity interactive prototypes** built in plain React/Babel. They are **design references, not production code**. Your task is to:

1. Read this README for exact token values, component specs, and per-screen layout details
2. Use the bundled HTML files as visual references (open in a browser, use focus mode to inspect individual screens)
3. Implement the designs in the existing React + TypeScript + Tailwind codebase, using its established patterns (React Query, React Router, existing component API surface)

Do **not** copy the prototype HTML directly. It does not use TypeScript, real API calls, or the project's build toolchain.

## Fidelity

**High-fidelity.** These mockups show final colours, typography, spacing, and interactions. Recreate pixel-accurately. Key visual elements to match:
- Exact token values (all listed below)
- Column bar charts in Reports (SVG, vertical bars, current month highlighted)
- Workflow rail in Watch Repair job detail (6-step progress track, clickable)
- Kanban board column header treatment (3px top accent bar + badge)
- Job card left-border accent (3px, matches column colour)
- Shoe repair photo grid as hero section (4-col grid at top of detail page)

---

## Design Token Spec — "Refined Warmth"

Replace the existing `--cafe-*` custom properties in `frontend/src/index.css` with the following. Keep the same variable naming pattern so existing usages continue to resolve (or do a find-and-replace as noted in the migration section).

```css
@import "tailwindcss";

/* Google Fonts — must be added to index.html <head> */
/* <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"> */

/* ── Refined Warmth tokens ──────────────────────────────────── */
:root {
  /* Backgrounds */
  --ms-bg:              #F5F1EC;   /* page background — warm off-white */
  --ms-surface:         #FDFCF9;   /* card / modal / input backgrounds */
  --ms-surface-alt:     #EDE7DF;   /* alternate surface (hero stats, table headers) */
  --ms-hover:           #F0EAE1;   /* hover state for list rows / cards */

  /* Text */
  --ms-text:            #1A1410;   /* primary text */
  --ms-text-mid:        #5C4B3C;   /* secondary text */
  --ms-text-muted:      #8E7B6B;   /* muted / labels / captions */

  /* Borders */
  --ms-border:          #E2D9CE;   /* standard border */
  --ms-border-strong:   #C8BEB2;   /* stronger border (dividers, table separators) */

  /* Accent — gold */
  --ms-accent:          #9A6E26;   /* primary action colour */
  --ms-accent-hover:    #7A5520;   /* hover state for accent */
  --ms-accent-light:    #F6EDD8;   /* accent tint for backgrounds */
  --ms-accent-pop:      rgba(154, 110, 38, 0.10); /* subtle accent fill */

  /* Sidebar */
  --ms-sidebar:         #1C1510;   /* sidebar background */
  --ms-sidebar-text:    #BCA898;   /* sidebar nav text */
  --ms-sidebar-act-text:#EDE0CE;   /* active nav item text */
  --ms-sidebar-active:  rgba(255, 255, 255, 0.08);  /* active nav background */
  --ms-sidebar-hover:   rgba(255, 255, 255, 0.05);  /* hover nav background */
  --ms-sidebar-border:  rgba(255, 255, 255, 0.07);  /* sidebar internal borders */

  /* Radius */
  --ms-radius:          12px;  /* cards, modals, column headers */
  --ms-radius-sm:       8px;   /* buttons, inputs, badges, small cards */

  /* Shadows */
  --ms-shadow:          0 1px 3px rgba(60, 30, 10, 0.05), 0 4px 16px rgba(60, 30, 10, 0.05);
  --ms-shadow-hover:    0 4px 12px rgba(60, 30, 10, 0.08), 0 16px 36px rgba(60, 30, 10, 0.08);

  /* Status badge colours */
  --ms-badge-wait-bg:   #FFF7E5;  --ms-badge-wait-text:  #8A5A10;
  --ms-badge-in-bg:     #E8F2F8;  --ms-badge-in-text:    #1E6A8A;
  --ms-badge-done-bg:   #EBF8EF;  --ms-badge-done-text:  #1A6A3A;
  --ms-badge-alert-bg:  #FEEEED;  --ms-badge-alert-text: #8B3A2A;
  --ms-badge-neutral-bg:#EEEBE5;  --ms-badge-neutral-text:#7A6A5A;
  --ms-badge-blue-bg:   #EAF1FB;  --ms-badge-blue-text:  #2A5598;
  --ms-badge-teal-bg:   #E2F4F0;  --ms-badge-teal-text:  #1A6860;
  --ms-badge-orange-bg: #FFF0E0;  --ms-badge-orange-text:#9A5010;
  --ms-badge-green-bg:  #E8F5ED;  --ms-badge-green-text: #1A6838;
}

/* Dark mode (Night Workshop) — wrap in @media or data-theme attribute */
[data-theme="dark"] {
  --ms-bg:              #121110;
  --ms-surface:         #1C1A18;
  --ms-surface-alt:     #242220;
  --ms-hover:           #2A2825;
  --ms-text:            #F0EAE0;
  --ms-text-mid:        #BEB4A8;
  --ms-text-muted:      #7A726A;
  --ms-border:          rgba(255, 255, 255, 0.08);
  --ms-border-strong:   rgba(255, 255, 255, 0.14);
  --ms-accent:          #D4940A;
  --ms-accent-hover:    #F0A820;
  --ms-accent-light:    rgba(212, 148, 10, 0.14);
  --ms-accent-pop:      rgba(212, 148, 10, 0.09);
  --ms-sidebar:         #0C0B0A;
  --ms-sidebar-text:    #887A6E;
  --ms-sidebar-act-text:#E8D8C0;
  --ms-sidebar-active:  rgba(255, 255, 255, 0.08);
  --ms-sidebar-hover:   rgba(255, 255, 255, 0.04);
  --ms-sidebar-border:  rgba(255, 255, 255, 0.05);
  --ms-radius:          10px;
  --ms-radius-sm:       6px;
  --ms-shadow:          0 1px 4px rgba(0,0,0,0.3), 0 4px 16px rgba(0,0,0,0.25);
  --ms-shadow-hover:    0 4px 16px rgba(0,0,0,0.4), 0 12px 40px rgba(0,0,0,0.35);
  --ms-badge-wait-bg:   rgba(200,150,20,0.15);  --ms-badge-wait-text:  #D8C060;
  --ms-badge-in-bg:     rgba(60,130,200,0.15);  --ms-badge-in-text:    #70B8F0;
  --ms-badge-done-bg:   rgba(60,170,90,0.15);   --ms-badge-done-text:  #70D890;
  --ms-badge-alert-bg:  rgba(200,70,70,0.15);   --ms-badge-alert-text: #F09090;
  --ms-badge-neutral-bg:rgba(255,255,255,0.07); --ms-badge-neutral-text:#A09080;
  --ms-badge-blue-bg:   rgba(50,120,200,0.14);  --ms-badge-blue-text:  #80C0F0;
  --ms-badge-teal-bg:   rgba(30,150,130,0.14);  --ms-badge-teal-text:  #60D8C0;
  --ms-badge-orange-bg: rgba(210,130,30,0.14);  --ms-badge-orange-text:#E0A040;
  --ms-badge-green-bg:  rgba(50,170,80,0.14);   --ms-badge-green-text: #70D890;
}

/* Neutral variant (Steel & Amber) — if you want to offer this as an option */
[data-theme="neutral"] {
  --ms-bg:              #F6F5F3;
  --ms-surface:         #FFFFFF;
  --ms-surface-alt:     #EEECEA;
  --ms-hover:           #F3F1EE;
  --ms-text:            #141210;
  --ms-text-mid:        #4A4540;
  --ms-text-muted:      #87837D;
  --ms-border:          #E0DDD8;
  --ms-border-strong:   #C6C2BC;
  --ms-accent:          #C07820;
  --ms-accent-hover:    #9A5C0C;
  --ms-accent-light:    #FEF3E2;
  --ms-accent-pop:      rgba(192, 120, 32, 0.09);
  --ms-sidebar:         #181614;
  --ms-sidebar-text:    #A8A29C;
  --ms-sidebar-act-text:#EDEBE7;
  --ms-sidebar-active:  rgba(255, 255, 255, 0.07);
  --ms-sidebar-hover:   rgba(255, 255, 255, 0.04);
  --ms-sidebar-border:  rgba(255, 255, 255, 0.06);
  --ms-radius:          8px;
  --ms-radius-sm:       6px;
  --ms-shadow:          0 1px 2px rgba(0,0,0,0.05), 0 2px 8px rgba(0,0,0,0.04);
  --ms-shadow-hover:    0 2px 8px rgba(0,0,0,0.08), 0 8px 28px rgba(0,0,0,0.07);
}

@layer base {
  html, body {
    font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    background-color: var(--ms-bg);
    color: var(--ms-text);
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* Remove Playfair Display from headings — all Plus Jakarta Sans now */
  h1, h2, h3 {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: var(--ms-bg); }
  ::-webkit-scrollbar-thumb { background: var(--ms-border-strong); border-radius: 3px; }
}
```

### Token Migration Map

Find-replace the following in all TSX/CSS files:

| Old token | New token |
|-----------|-----------|
| `var(--cafe-bg)` | `var(--ms-bg)` |
| `var(--cafe-surface)` | `var(--ms-surface)` |
| `var(--cafe-paper)` | `var(--ms-surface)` |
| `var(--cafe-espresso)` | `var(--ms-sidebar)` |
| `var(--cafe-espresso-2)` | `color-mix(in srgb, var(--ms-sidebar) 80%, #fff)` |
| `var(--cafe-gold)` | `var(--ms-accent)` |
| `var(--cafe-amber)` | `var(--ms-accent)` |
| `var(--cafe-gold-dark)` | `var(--ms-accent-hover)` |
| `var(--cafe-border)` | `var(--ms-border)` |
| `var(--cafe-border-2)` | `var(--ms-border-strong)` |
| `var(--cafe-text)` | `var(--ms-text)` |
| `var(--cafe-text-mid)` | `var(--ms-text-mid)` |
| `var(--cafe-text-muted)` | `var(--ms-text-muted)` |
| `var(--cafe-sidebar-txt)` | `var(--ms-sidebar-text)` |
| `var(--cafe-link)` | `var(--ms-accent)` |

### Google Fonts

Add to `frontend/index.html` `<head>` — replace or supplement existing font link:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
```

Remove the existing Playfair Display and DM Sans imports.

---

## Typography Scale

All type is **Plus Jakarta Sans**. No serif. Remove `fontFamily: "'Playfair Display', Georgia, serif"` from all component inline styles.

| Role | Size | Weight | Letter-spacing | Usage |
|------|------|--------|---------------|-------|
| Display | 26–32px | 800 | -0.025em | Job numbers, large KPI values |
| H1 / Page title | 18–20px | 800 | -0.02em | Page headers |
| H2 / Card title | 13–14px | 700 | — | Card headers, section titles |
| Body / Primary | 13px | 500 | — | Main content text |
| Body / Secondary | 12px | 400–500 | — | Supporting content |
| Small | 11px | 400–600 | — | Meta info, dates |
| Label | 10px | 700 | 0.10–0.14em | Uppercase section labels |
| Micro | 9–10px | 600–700 | 0.08em | Badge text, chart labels |

---

## Component Specs

### Button

Four variants. All use `var(--ms-radius-sm)` border-radius.

```tsx
// Primary
background: var(--ms-accent)
color: #fff
border: 1px solid var(--ms-accent)
padding: 8px 16px (normal) | 5px 11px (small)
font-size: 13px (normal) | 11px (small)
font-weight: 600
hover: background → var(--ms-accent-hover)

// Secondary
background: var(--ms-surface)
color: var(--ms-text-mid)
border: 1px solid var(--ms-border)
hover: background → var(--ms-hover)

// Ghost
background: transparent
color: var(--ms-text-mid)
border: 1px solid transparent
hover: background → var(--ms-hover)

// Danger
background: #7A3020
color: #fff
border: 1px solid #7A3020
hover: background → #5A2015

// Subtle (new variant — for secondary accent actions)
background: var(--ms-accent-pop)
color: var(--ms-accent)
border: 1px solid var(--ms-accent-light)
```

### Badge (status)

```tsx
display: inline-flex
align-items: center
gap: 4–5px
padding: 3px 9px
border-radius: 99px
font-size: 11px
font-weight: 600
letter-spacing: 0.015em

// Status → colour mapping (bg / text):
awaiting_quote       → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)
awaiting_go_ahead    → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)
go_ahead             → var(--ms-badge-in-bg)   / var(--ms-badge-in-text)
working_on           → var(--ms-badge-in-bg)   / var(--ms-badge-in-text)
awaiting_parts       → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)
parts_to_order       → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)
sent_to_labanda      → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)
service              → var(--ms-badge-in-bg)   / var(--ms-badge-in-text)
completed            → var(--ms-badge-done-bg) / var(--ms-badge-done-text)
awaiting_collection  → var(--ms-badge-neutral-bg) / var(--ms-badge-neutral-text)
collected            → var(--ms-badge-done-bg) / var(--ms-badge-done-text)
en_route             → var(--ms-badge-orange-bg) / var(--ms-badge-orange-text)
on_site              → var(--ms-badge-orange-bg) / var(--ms-badge-orange-text)
work_completed       → var(--ms-badge-green-bg) / var(--ms-badge-green-text)
invoice_paid         → var(--ms-badge-done-bg) / var(--ms-badge-done-text)
failed_job           → var(--ms-badge-alert-bg) / var(--ms-badge-alert-text)
booking_confirmed    → var(--ms-badge-teal-bg) / var(--ms-badge-teal-text)
quote_sent           → var(--ms-badge-blue-bg) / var(--ms-badge-blue-text)
awaiting_booking_confirmation → var(--ms-badge-wait-bg) / var(--ms-badge-wait-text)

// Dot indicator before label:
<span style={{ width: 5, height: 5, borderRadius: '50%', background: currentColor, opacity: 0.75 }} />
```

### Card

```tsx
background: var(--ms-surface)
border: 1px solid var(--ms-border)
border-radius: var(--ms-radius)
box-shadow: var(--ms-shadow)

// Hover variant (clickable cards):
transition: transform 0.18s ease, box-shadow 0.18s ease
hover: transform translateY(-2px), box-shadow: var(--ms-shadow-hover)
```

### Input / Select

```tsx
height: 34–36px
background: var(--ms-surface)
border: 1px solid var(--ms-border)
border-radius: var(--ms-radius-sm)
padding: 0 12px
font-size: 13px
color: var(--ms-text)
outline: none
focus: border-color → var(--ms-accent), ring: 2px var(--ms-accent-pop)

// Label above input:
font-size: 10px
font-weight: 700
text-transform: uppercase
letter-spacing: 0.10em
color: var(--ms-text-muted)
margin-bottom: 4–5px
```

### Modal

```tsx
backdrop: rgba(28, 21, 16, 0.50), backdrop-filter: blur(4px)
container:
  background: var(--ms-surface)
  border: 1px solid var(--ms-border)
  border-radius: var(--ms-radius)
  box-shadow: 0 20px 60px rgba(0,0,0,0.25)
  max-width: 780px (wide) | 480px (default)
header:
  background: var(--ms-bg)
  padding: 14–16px 22–24px
  border-bottom: 1px solid var(--ms-border)
body: padding: 18–20px 22–24px
footer:
  background: var(--ms-bg)
  padding: 12–14px 22–24px
  border-top: 1px solid var(--ms-border)
  display: flex, justify-content: space-between
```

### PageHeader

Remove `fontFamily: "'Playfair Display', Georgia, serif"`. New spec:

```tsx
h1:
  font-size: 18–20px
  font-weight: 800
  color: var(--ms-text)
  letter-spacing: -0.02em

// Gold accent underline (keep this — it's distinctive):
margin-top: 4–5px
height: 2px
width: 24–28px
background: var(--ms-accent)
border-radius: 2px
```

### Sidebar

```tsx
width: 216px
background: var(--ms-sidebar)
border-right: 1px solid var(--ms-sidebar-border)

// Logo area:
padding: 20px 16px 16px
border-bottom: 1px solid var(--ms-sidebar-border)
Logo mark: 28×28px, border-radius: 8px, background: var(--ms-accent)
  SVG: watch face (circle + hour/minute hands) in white
Name: "Mainspring", 14px, font-weight: 700, color: var(--ms-sidebar-act-text)

// Nav item (normal):
padding: 8px 12px
border-radius: var(--ms-radius-sm)
color: var(--ms-sidebar-text)
font-size: 13px, font-weight: 400
hover: background → var(--ms-sidebar-hover)

// Nav item (active):
background: var(--ms-sidebar-active)
border: 1px solid var(--ms-sidebar-border)
color: var(--ms-sidebar-act-text)
font-weight: 600
left accent bar: position absolute, left: 0, top: 22%, bottom: 22%, width: 3px, border-radius: 3px, background: var(--ms-accent)

// Inbox badge:
background: #C96A5A, color: #fff, border-radius: 99px, padding: 1px 6px, font-size: 10px, font-weight: 700

// Section divider between nav groups:
height: 1px, background: var(--ms-sidebar-border), margin: 6px

// Bottom area (What's new / Sign out):
padding: 7px 12px, font-size: 12px, color: var(--ms-sidebar-text)
border-top: 1px solid var(--ms-sidebar-border)
```

### Topbar

```tsx
height: 46px
background: var(--ms-surface)
border-bottom: 1px solid var(--ms-border)
padding: 0 20px
display: flex, align-items: center, gap: 10px
```

### View toggle (Board/List; Kanban/List etc.)

```tsx
container:
  display: flex, gap: 2px
  background: var(--ms-bg)
  border-radius: var(--ms-radius-sm)
  padding: 3px

button (active):
  background: var(--ms-surface)
  color: var(--ms-accent)
  font-weight: 700
  box-shadow: var(--ms-shadow)
  border-radius: var(--ms-radius-sm)

button (inactive):
  background: var(--ms-bg)
  color: var(--ms-text-muted)
  font-weight: 400
```

### Kanban Column

```tsx
width: 222–234px (fixed, flex-shrink: 0)
column header:
  top accent bar: height 3px, background: col.color (see colour list below)
  header row: background var(--ms-surface), padding 8px 12px
    label: font-size 11px, font-weight 700, color var(--ms-text)
    count badge: font-size 11px, font-weight 700, padding 2px 7px, border-radius 99px, background col.bg, color col.color
  border: 1px solid var(--ms-border), border-top: none
  border-radius: var(--ms-radius) var(--ms-radius) 0 0 (on outer wrapper)
column body:
  background: var(--ms-bg)
  border: 1px solid var(--ms-border), border-top: none
  border-radius: 0 0 var(--ms-radius) var(--ms-radius)
  padding: 10px 8px

// Column colours:
Quote Needed / Awaiting Quote:     color #9A6E26, bg #F6EDD8
Awaiting Approval / Go-Ahead:      color #2A5FA0, bg #EDF3FA
In Work (working_on + sub):        color #6840B4, bg #F3EBF9
Completed:                         color #1A6A3A, bg #EBF8EF
Ready to Collect:                  color #5A4A3B, bg #EEEBE5
Mobile — Quote Sent:               color #2A5FA0, bg #EDF3FA
Mobile — Booking Confirmed:        color #1A7068, bg #E2F4F0
Mobile — En Route/On Site:         color #B06010, bg #FFF0E0
Mobile — Work Completed:           color #1E7040, bg #E8F5ED
```

### Job Card (Watch/Shoe board)

```tsx
background: var(--ms-surface)
border: 1px solid var(--ms-border)
border-left: 3px solid col.color   // ← KEY: coloured left accent border
border-radius: var(--ms-radius-sm)
padding: 11px 12px
margin-bottom: 8px
box-shadow: var(--ms-shadow)
cursor: pointer

// Selected state:
border-color: col.color
box-shadow: 0 0 0 2px rgba(col.color, 0.13), var(--ms-shadow)

// Job number: font-size 10px, font-weight 700, color col.color
// Title: font-size 12px, font-weight 700, color var(--ms-text)
// Description: font-size 11px, color var(--ms-text-muted)
// Customer: font-size 11px, font-weight 500, color var(--ms-text-mid)

// Priority badge (urgent/high only — normal/low silent):
urgent: bg #FEEEED, text #8B3A2A, label "Urgent"
high:   bg #FFF0E0, text #8A5010, label "High"

// Days aging pill:
0–6d:   bg #EBF8EF, text #3A6A3A
7–13d:  bg #FFF0E0, text #9A5010
14d+:   bg #FEEEED, text #8B3A2A

// Footer (below border-top: 1px solid var(--ms-border)):
Tech avatar: 20px circle, initials, background per tech (see tech colours)
Quote: font-size 12px, font-weight 700, color var(--ms-text)
```

### Workflow Rail (Watch Repair job detail — NEW COMPONENT)

Replace the row of 10 status `<button>` elements with this:

```tsx
// Container:
background: var(--ms-surface)
border-bottom: 1px solid var(--ms-border)
padding: 16px 24px
display: flex, align-items: center

// 6 stages:
const WATCH_STEPS = [
  { key: 'received',   label: 'Received',    statuses: ['awaiting_quote'] },
  { key: 'quoted',     label: 'Quoted',      statuses: ['awaiting_go_ahead', 'quote_sent'] },
  { key: 'approved',   label: 'Approved',    statuses: ['go_ahead', 'awaiting_parts', 'parts_to_order', 'sent_to_labanda', 'quoted_by_labanda'] },
  { key: 'working',    label: 'In Workshop', statuses: ['working_on', 'service'] },
  { key: 'complete',   label: 'Completed',   statuses: ['completed'] },
  { key: 'collected',  label: 'Collected',   statuses: ['awaiting_collection', 'collected'] },
]

// Node (past): 30px circle, background var(--ms-accent), check icon (white)
// Node (current): 30px circle, background var(--ms-accent), white dot center
//   box-shadow: 0 0 0 4px var(--ms-accent-pop)
// Node (future): 30px circle, background var(--ms-border), muted dot center

// Connector line: flex: 1, height: 2px, margin: 0 6px, margin-bottom: 18px
//   past: background var(--ms-accent)
//   future: background var(--ms-border)

// Labels: font-size 10px, letter-spacing 0.01em
//   current: font-weight 700, color var(--ms-accent)
//   past: font-weight 500, color var(--ms-text-mid)
//   future: font-weight 500, color var(--ms-text-muted)

// Clicking a step calls quickStatusAction(jobId, step.statuses[0])
```

### Shoe Repair — Multi-pair Tabs

```tsx
// Pair tab strip (within the Shoes card):
display: flex, overflow-x: auto
border-bottom: 1px solid var(--ms-border)

// Tab button:
flex: 1, padding: 7px 4px
font-size: 10px
font-weight: active ? 700 : 500
color: active ? var(--ms-accent) : var(--ms-text-muted)
border-bottom: 2px solid (active ? var(--ms-accent) : transparent)
transition: all 0.12s
```

### Shoe Repair — Photo Grid Hero

Move photos to the **top** of the job detail page (above the grid), not in a sidebar card:

```tsx
// Section container (full width):
background: var(--ms-surface)
border: 1px solid var(--ms-border)
border-radius: var(--ms-radius)
padding: 14px 16px
margin-bottom: 12px

// Photo grid: display grid, grid-template-columns: repeat(4, 1fr), gap: 6px
// Each cell: aspect-ratio: 1, border-radius: var(--ms-radius-sm), overflow: hidden
// Add photo cell: dashed border, flex center, camera icon + "Add photo" label
```

### Reports — Vertical Bar Chart (NEW COMPONENT)

Replace the horizontal bar rows with:

```tsx
// Container: height 120px, display flex, gap 4px, align-items flex-end, padding 0 4px
// Per bar:
  flex: 1
  display flex, flex-direction: column, align-items: center, gap: 4px
  
  Value label (above bar):
    font-size: 9px, font-weight: 700
    color: isCurrentMonth ? var(--ms-accent) : var(--ms-text-muted)
  
  Bar:
    width: 100%
    height: (value / maxValue) * 100%, min-height: 4px
    background: isCurrentMonth ? barColor : barColor + "60" (60% opacity hex)
    border-radius: 3px 3px 0 0
  
  Month label (below):
    font-size: 9px
    color: isCurrentMonth ? var(--ms-accent) : var(--ms-text-muted)
    font-weight: isCurrentMonth ? 700 : 400

// Revenue chart bar colour: #1A6A3A
// Jobs chart bar colour: var(--ms-accent)
```

### Reports — Sales Funnel (NEW COMPONENT)

```tsx
// Per stage:
  Stage label row: display flex, justify-between, margin-bottom 5px
    Label: font-size 12px, color var(--ms-text-mid)
    Count: font-size 12px, font-weight 700, color var(--ms-text)
    Pct: font-size 11px, font-weight 600
      pct >= 70: color #1A6A3A
      pct >= 50: color var(--ms-text-mid)
      pct < 50:  color #9A5010

  Bar container: height 28px, background var(--ms-bg), border-radius var(--ms-radius-sm)
  Bar fill:
    height 100%, background stage.color (85% opacity)
    width: pct%
    border-radius: var(--ms-radius-sm)
    Inside label: font-size 10px, font-weight 700, color #fff (only if pct > 25)

// Funnel stage colours:
  Quotes Sent:     #9A6E26
  Quote Approved:  #2A5FA0
  Invoiced:        #6840B4
  Invoice Paid:    #1A6A3A
```

---

## Screen Breakdown

### Dashboard

**Reference:** `Mainspring Visual Overhaul.html` → Section "02 · Dashboard" → Artboard "A · Refined Warmth"

Changes from current:
- Stat cards: reduce padding from `p-4 sm:p-5` to `p-4`, reduce value font from `text-2xl sm:text-3xl` Playfair → `text-[26px] font-extrabold` Plus Jakarta
- Hero card: keep dark gradient, update font to Plus Jakarta
- Stat card icon bg/colour values stay (they're already good in the current implementation)
- Dashboard rise animation — keep as-is

### Watch Repairs — Jobs Page

**Reference:** `Mainspring Watch Repairs.html` → Artboards 01 (Board) and 02 (List)

Key changes:
- **Replace** the status-grouped `<Card>` grid with a proper horizontal-scroll Kanban board using grouped stages (5 columns as per kanban column spec above)
- **Remove** the inline `<select>` dropdown per job row — the quickStatusAction should move to the job detail workflow rail
- **Add** Board / List view toggle in the topbar
- **Board cards** use the Job Card spec above (left-border accent, priority/aging pills)
- **List view** is a table with columns: # | Watch & Description | Customer | Status | Priority | Days | Quote | Collection | Tech
- Days aging column: coloured text (green/amber/red per aging pill spec)

### Watch Repair — Job Detail

**Reference:** `Mainspring Job + Mobile.html` → Section "01 · Job Ticket" → Artboard "Watch Repair · Job Detail"

Key changes:
- **Add** `WorkflowRail` component below the topbar (see component spec above)
- **Tabs** — keep existing tabs (Details, Work Logs, Attachments, History, Messages) but restyle:
  `border-bottom: 2px solid var(--ms-accent)` for active, `color: var(--ms-accent)` for active label
- **Job Info left panel** — restyle as ticket stub:
  - Dark header (`background: var(--ms-sidebar)`) with large job # (`font-size: 32px, font-weight: 800, color: #fff`)
  - Perforated divider: `border-top: 1px dashed var(--ms-border), margin: 0 12px`
  - Key/value rows: label 10px muted, value 11px semibold right-aligned
  - Quote amount: `font-size: 22px, font-weight: 800`
- **Remove** `fontFamily: "'Playfair Display'"` from Quotes card heading
- Keep status modal, step note modal as-is functionally — just update styling to new tokens

### Shoe Repairs — Jobs Page

**Reference:** `Mainspring Shoe Repairs.html` → Artboard 01 (Board)

Key changes:
- Same board pattern as Watch Repairs but with 4 columns (Quote Needed, Awaiting Approval, In Work, Ready to Collect)
- Cards show: **complexity pill** (Standard/Intermediate/Advanced), **multi-pair badge** (if pairs > 1), expandable services, photo count
- Complexity pill colours:
  - Standard:     bg #E8F5EC, text #1A6838
  - Intermediate: bg #EDF3FB, text #245498
  - Advanced:     bg #F5EEFB, text #6040A8

### Shoe Repair — Job Detail

**Reference:** `Mainspring Shoe Repairs.html` → Artboard 02 (Job Detail)

Key changes:
- Move **Photos section to the top** of the page (before the main grid), full-width, 4-col photo grid
- Multi-pair tab system (see component spec)
- **Services as receipt table**: columns Service | Category | Qty | Price — not plain text list
- Remove inline `<select>` status footer from job list cards — status change moves to header action button

### Mobile Services

**Reference:** `Mainspring Mobile Services.html` — all 6 artboards

Key changes per view:
- **List:** table with sortable columns, status filter chips in topbar
- **Kanban:** 5 columns (see column colour spec), cards show vehicle + tech + schedule
- **Map:** keep existing `MobileServicesMap.tsx` implementation — update colours/fonts only
- **Planner:** keep existing week scheduler — update card colours to tech-assigned colours (Ben Carter: `#9A6E26`, Alex Singh: `#1A7068`)
- **POS:** category tabs + 3-col item grid on left, cart + customer + charge button on right
- **Reports:** vertical bar charts (revenue + jobs), tech leaderboard table, jobs-by-type horizontal bars

### Settings — Appearance (NEW SCREEN)

**Reference:** `Mainspring Job + Mobile.html` → Section "03 · Settings · Appearance"

Add a new settings subsection (within `/accounts` or a new `/settings` route) with:
- Three theme cards: Refined Warmth / Steel & Amber / Night Workshop
- Each card: mini UI preview (sidebar strip + content area snippet), label, description, selection ring
- Selection persists to `localStorage` under key `ms-theme` (values: `"warm"` | `"neutral"` | `"dark"`)
- On load, read `ms-theme` and apply `data-theme` attribute to `<html>` element
- Selected card: `border: 2px solid var(--ms-accent), box-shadow: 0 0 0 3px var(--ms-accent-pop)`

### Reports

**Reference:** `Mainspring Reports.html` → Artboards 01 (Overview) and 02 (Detail)

Key changes:
- **Remove** Playfair Display from `MetricCard` values
- **Add** period selector in topbar (This week / This month / Last 90 days / All time) — new query param `?period=month`
- **Trend charts** — replace horizontal bars with `VerticalBarChart` component (see spec)
- **Add** Sales Funnel component (new — see spec)
- **Add** service breakdown cards (Watch / Shoe / Mobile) between KPI cards and trend charts
- **Technician breakdown** — expand to full leaderboard table with performance bars
- **Audit log** — replace plain text list with colour-coded badge + summary row format

---

## Technician Avatar Colours

Use consistent colours for tech avatars across all service lines:

```tsx
const TECH_COLORS: Record<string, string> = {
  // These are fallbacks — ideal to derive from user.id hash
  // Assign on first render, store in context
}

// Preset palette (assign round-robin by user index):
const AVATAR_PALETTE = ['#9A6E26', '#1A7068', '#2A5FA0', '#6840B4', '#1A6A3A', '#8B3A2A']
```

---

## Theme Switching Implementation

```tsx
// src/context/ThemeContext.tsx (new file)

type Theme = 'warm' | 'neutral' | 'dark'

function applyTheme(theme: Theme) {
  const root = document.documentElement
  if (theme === 'dark') root.setAttribute('data-theme', 'dark')
  else if (theme === 'neutral') root.setAttribute('data-theme', 'neutral')
  else root.removeAttribute('data-theme')
  localStorage.setItem('ms-theme', theme)
}

// On app init (main.tsx):
const savedTheme = localStorage.getItem('ms-theme') as Theme | null
if (savedTheme) applyTheme(savedTheme)
```

---

## Assets

- **Mainspring logo** (`/mainspring-logo.svg`): existing file in `frontend/public/`, keep as-is
- **Sidebar logo mark**: inline SVG — watch face circle with hour/minute hands, white on `var(--ms-accent)` background
- **Icons**: continue using Lucide React (`lucide-react`) — no changes to icon set
- **Fonts**: Plus Jakarta Sans via Google Fonts (see import above)

---

## Files in This Package

| File | Contains |
|------|----------|
| `README.md` | This document — all tokens, specs, migration notes |
| `Mainspring Visual Overhaul.html` | Style system + Dashboard (3 directions side by side) |
| `Mainspring Job + Mobile.html` | Job Ticket detail · Mobile Services · Settings |
| `Mainspring Mobile Services.html` | All 6 Mobile Services views |
| `Mainspring Watch Repairs.html` | Board · List · New Job modal |
| `Mainspring Shoe Repairs.html` | Board · Job Detail · New Job modal |
| `Mainspring Reports.html` | Overview · Funnel + Leaderboard + Audit |

Open any HTML file in a browser. Use the Tweaks panel (bottom-right) to switch between Refined Warmth (A), Steel & Amber (B), and Night Workshop (C). Click any artboard label to open it fullscreen. ←/→ arrow keys navigate between artboards in focus mode.

---

## Implementation Order (suggested)

1. `index.css` — swap tokens, add Google Fonts import
2. `components/ui.tsx` — update Button, Card, Badge, Input, Modal, PageHeader
3. `components/Sidebar.tsx` — update styles, keep nav logic
4. `AppShell.tsx` — update topbar height/styling
5. `pages/DashboardPage.tsx` — stat cards, hero, no layout changes needed
6. `pages/JobsPage.tsx` — add Board/List toggle, kanban column layout, new job cards
7. `pages/JobDetailPage.tsx` — add WorkflowRail component, ticket stub left panel
8. `pages/ShoeRepairsPage.tsx` — board layout, card updates
9. `pages/ShoeJobDetailPage.tsx` — photo hero, pair tabs, services table
10. `pages/AutoKeyJobsPage.tsx` — update sub-nav, kanban columns, card styling
11. `pages/ReportsPage.tsx` — VerticalBarChart, SalesFunnel, service breakdown cards
12. Settings — add theme switching (localStorage + data-theme)
